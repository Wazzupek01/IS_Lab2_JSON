#!/bin/sh
dotnet run --project ./tools/build/build.csproj -- $@
